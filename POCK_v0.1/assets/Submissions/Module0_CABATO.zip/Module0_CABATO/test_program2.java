class HelloAgain {
    public static void main(String args[]) {
        System.out.println("Hi, World");
    }
}