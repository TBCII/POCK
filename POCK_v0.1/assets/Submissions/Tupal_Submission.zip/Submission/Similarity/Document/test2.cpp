#include <iostream>
using namespace std;
int main()
{
cout << "Hi, World!";
return 0;
}