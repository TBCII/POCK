import java.io.*;

public class NMain {
    public static void main(String[] args) throws IOException
    {
        double total=0, simi=0;
        float perc = (10/5);
        System.out.println("The similarity percentage of two files are "+ perc + "%.");
    }
}
