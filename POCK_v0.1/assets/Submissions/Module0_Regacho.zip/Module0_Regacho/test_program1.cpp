#include <iostream>

using namespace std;

int main1(){
    
    cout<<"Hello, World!";
    
    return 0;
    
}

