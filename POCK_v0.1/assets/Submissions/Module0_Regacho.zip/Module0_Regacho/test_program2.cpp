#include <iostream>

using namespace std;

int main2(){
    
    cout<<"Hi, World!";
    
    return 0;
    
}

